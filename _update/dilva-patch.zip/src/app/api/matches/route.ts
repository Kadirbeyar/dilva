import { NextResponse } from "next/server";
import { requireUser, AuthError } from "@/lib/auth";
import { findLanguagePartners, browseAllUsers, type SearchFilters } from "@/lib/matching";
import { isPremiumUser } from "@/lib/premium";
import type { Gender } from "@prisma/client";

const VALID_GENDERS = new Set(["MALE", "FEMALE", "OTHER", "PREFER_NOT_TO_SAY"]);

export async function GET(req: Request) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);

    // Age/gender/language search filters are a Premium feature — the
    // UI shows them to everyone but only sends them once the viewer
    // is Premium; we also re-check server-side so the restriction
    // can't be bypassed by calling the API directly.
    const premium = await isPremiumUser(user.id);
    const searchFilters: SearchFilters = {};
    if (premium) {
      const minAge = searchParams.get("minAge");
      const maxAge = searchParams.get("maxAge");
      const gender = searchParams.get("gender");
      const languageCode = searchParams.get("languageCode");
      if (minAge) searchFilters.minAge = Number(minAge);
      if (maxAge) searchFilters.maxAge = Number(maxAge);
      if (gender && VALID_GENDERS.has(gender)) searchFilters.gender = gender as Gender;
      if (languageCode) searchFilters.languageCode = languageCode;
    }

    const mode = searchParams.get("mode") === "all" ? "all" : "matches";
    const commonFilters = {
      country: searchParams.get("country") ?? undefined,
      onlineOnly: searchParams.get("online") === "true",
      cursor: searchParams.get("cursor") ?? undefined,
      ...searchFilters,
    };

    const results =
      mode === "all"
        ? await browseAllUsers(user.id, commonFilters)
        : await findLanguagePartners(user.id, commonFilters);

    return NextResponse.json({
      mode,
      premiumFiltersApplied: premium && Object.keys(searchFilters).length > 0,
      results: results.map((r) => ({
        matchScore: r.matchScore,
        user: {
          id: r.user.id,
          username: r.user.username,
          displayName: r.user.displayName,
          avatarUrl: r.user.avatarUrl,
          bio: r.user.bio,
          country: r.user.country,
          city: r.user.city,
          isOnline: r.user.isOnline,
          birthDate: r.user.birthDate,
          gender: r.user.gender,
          languages: r.user.languages,
        },
      })),
    });
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    }
    console.error("[matches]", err);
    return NextResponse.json({ error: "server_error" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUser, AuthError } from "@/lib/auth";
import { calculateAge, MIN_SIGNUP_AGE } from "@/lib/age";

const languageSelectionSchema = z.object({
  code: z.string().min(2),
  proficiency: z
    .enum(["BEGINNER", "ELEMENTARY", "INTERMEDIATE", "ADVANCED", "FLUENT"])
    .optional(),
});

const bodySchema = z.object({
  username: z
    .string()
    .min(3)
    .max(30)
    .regex(/^[a-zA-Z0-9_]+$/, "letters, numbers and underscores only"),
  displayName: z.string().max(60).optional(),
  bio: z.string().max(500).optional(),
  avatarUrl: z.string().url().optional().or(z.literal("")),
  country: z.string().max(60).optional(),
  city: z.string().max(60).optional(),
  // Mandatory — every profile must state an age (see lib/age.ts for
  // the minimum), enforced below rather than as a DB constraint so
  // it doesn't break already-onboarded rows.
  birthDate: z.string().refine((v) => !Number.isNaN(Date.parse(v)), "invalid date"),
  gender: z.enum(["MALE", "FEMALE", "OTHER", "PREFER_NOT_TO_SAY"]).optional(),
  nativeLanguages: z.array(languageSelectionSchema).min(1),
  targetLanguages: z.array(languageSelectionSchema).min(1).max(4),
});

/**
 * Finishes onboarding for the current Supabase-authenticated user:
 * sets their (self-chosen) username + profile fields and their
 * native/target languages, which feed the matching engine.
 */
export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const json = await req.json();
    const body = bodySchema.parse(json);

    const birthDate = new Date(body.birthDate);
    if (calculateAge(birthDate) < MIN_SIGNUP_AGE) {
      return NextResponse.json(
        { error: "underage", minAge: MIN_SIGNUP_AGE },
        { status: 400 }
      );
    }

    const usernameOwner = await prisma.user.findUnique({
      where: { username: body.username },
      select: { id: true },
    });
    if (usernameOwner && usernameOwner.id !== user.id) {
      return NextResponse.json(
        { error: "username_taken" },
        { status: 409 }
      );
    }

    const updated = await prisma.$transaction(async (tx) => {
      const profile = await tx.user.update({
        where: { id: user.id },
        data: {
          username: body.username,
          displayName: body.displayName,
          bio: body.bio,
          avatarUrl: body.avatarUrl || undefined,
          country: body.country,
          city: body.city,
          birthDate,
          gender: body.gender,
        },
      });

      // Replace language selections wholesale — simplest correct
      // behaviour for an onboarding/edit-profile form.
      await tx.userLanguage.deleteMany({ where: { userId: user.id } });
      await tx.userLanguage.createMany({
        data: [
          ...body.nativeLanguages.map((l, i) => ({
            userId: user.id,
            languageCode: l.code,
            type: "NATIVE" as const,
            isPrimary: i === 0,
          })),
          ...body.targetLanguages.map((l, i) => ({
            userId: user.id,
            languageCode: l.code,
            type: "LEARNING" as const,
            proficiency: l.proficiency ?? "BEGINNER",
            isPrimary: i === 0,
          })),
        ],
      });

      return profile;
    });

    return NextResponse.json({ user: updated });
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    }
    if (err instanceof z.ZodError) {
      return NextResponse.json(
        { error: "validation_error", issues: err.issues },
        { status: 400 }
      );
    }
    console.error("[profile/complete]", err);
    return NextResponse.json({ error: "server_error" }, { status: 500 });
  }
}

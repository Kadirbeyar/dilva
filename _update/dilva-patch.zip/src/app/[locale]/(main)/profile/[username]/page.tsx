import { notFound } from "next/navigation";
import { getTranslations } from "next-intl/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { calculateAge } from "@/lib/age";
import LanguageFlag from "@/components/shared/LanguageFlag";
import RecordVisit from "@/components/profile/RecordVisit";

export default async function PublicProfilePage({
  params,
}: {
  params: Promise<{ username: string }>;
}) {
  const { username } = await params;
  const t = await getTranslations("profile");

  const profile = await prisma.user.findUnique({
    where: { username },
    include: { languages: { include: { language: true } } },
  });
  if (!profile) notFound();

  const viewer = await getCurrentUser();
  const native = profile.languages.filter((l) => l.type === "NATIVE");
  const learning = profile.languages.filter((l) => l.type === "LEARNING");

  return (
    <main className="mx-auto max-w-2xl px-4 py-8">
      {viewer && viewer.username !== username && (
        <RecordVisit visitedUsername={username} />
      )}

      <div className="flex items-center gap-4">
        <div className="h-20 w-20 overflow-hidden rounded-full bg-gray-200">
          {profile.avatarUrl && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={profile.avatarUrl} alt="" className="h-full w-full object-cover" />
          )}
        </div>
        <div>
          <h1 className="text-2xl font-bold">{profile.displayName || profile.username}</h1>
          <p className="text-gray-500">
            @{profile.username}
            {profile.birthDate && (
              <span className="ms-2">· {t("yearsOld", { age: calculateAge(profile.birthDate) })}</span>
            )}
          </p>
        </div>
      </div>

      {profile.bio && <p className="mt-4 whitespace-pre-wrap">{profile.bio}</p>}

      <div className="mt-6 grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs font-medium uppercase text-gray-500">{t("native")}</p>
          <ul className="mt-1 flex flex-col gap-1 text-sm">
            {native.map((l) => (
              <li key={l.id} className="flex items-center gap-1.5">
                <LanguageFlag code={l.languageCode} />
                {l.language.nativeName}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-xs font-medium uppercase text-gray-500">{t("learning")}</p>
          <ul className="mt-1 flex flex-col gap-1 text-sm">
            {learning.map((l) => (
              <li key={l.id} className="flex items-center gap-1.5">
                <LanguageFlag code={l.languageCode} />
                {l.language.nativeName}
                {l.proficiency ? ` · ${l.proficiency}` : ""}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </main>
  );
}

"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import LanguageFlag from "@/components/shared/LanguageFlag";
import { flagEmoji } from "@/lib/languageFlags";
import { calculateAge } from "@/lib/age";

type MatchUser = {
  id: string;
  username: string;
  displayName: string | null;
  avatarUrl: string | null;
  bio: string | null;
  country: string | null;
  isOnline: boolean;
  birthDate: string | null;
  gender: string | null;
  languages: { languageCode: string; type: string }[];
};

type Match = { matchScore: 1 | 2; user: MatchUser };
type Language = { code: string; name: string; nativeName: string };

export default function MatchesPage() {
  const t = useTranslations("matches");
  const tProfile = useTranslations("profile");
  const router = useRouter();

  const [mode, setMode] = useState<"matches" | "all">("matches");
  const [matches, setMatches] = useState<Match[]>([]);
  const [onlineOnly, setOnlineOnly] = useState(false);
  const [country, setCountry] = useState("");
  const [loading, setLoading] = useState(true);
  const [isPremium, setIsPremium] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [languages, setLanguages] = useState<Language[]>([]);

  const [minAge, setMinAge] = useState("");
  const [maxAge, setMaxAge] = useState("");
  const [gender, setGender] = useState("");
  const [languageCode, setLanguageCode] = useState("");
  const [appliedFilters, setAppliedFilters] = useState<{
    minAge: string;
    maxAge: string;
    gender: string;
    languageCode: string;
  }>({ minAge: "", maxAge: "", gender: "", languageCode: "" });

  useEffect(() => {
    fetch("/api/profile/me")
      .then((r) => r.json())
      .then((d) => setIsPremium(Boolean(d.profile?.isPremiumCached)));
    fetch("/api/languages")
      .then((r) => r.json())
      .then((d) => setLanguages(d.languages ?? []));
  }, []);

  useEffect(() => {
    const params = new URLSearchParams();
    params.set("mode", mode);
    if (onlineOnly) params.set("online", "true");
    if (country) params.set("country", country);
    if (isPremium) {
      if (appliedFilters.minAge) params.set("minAge", appliedFilters.minAge);
      if (appliedFilters.maxAge) params.set("maxAge", appliedFilters.maxAge);
      if (appliedFilters.gender) params.set("gender", appliedFilters.gender);
      if (appliedFilters.languageCode) params.set("languageCode", appliedFilters.languageCode);
    }

    setLoading(true);
    fetch(`/api/matches?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => setMatches(d.results ?? []))
      .finally(() => setLoading(false));
  }, [mode, onlineOnly, country, isPremium, appliedFilters]);

  function applyFilters() {
    if (!isPremium) return;
    setAppliedFilters({ minAge, maxAge, gender, languageCode });
    setShowFilters(false);
  }

  function clearFilters() {
    setMinAge("");
    setMaxAge("");
    setGender("");
    setLanguageCode("");
    setAppliedFilters({ minAge: "", maxAge: "", gender: "", languageCode: "" });
  }

  async function sayHi(userId: string) {
    const res = await fetch("/api/conversations/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ otherUserId: userId }),
    });
    if (res.ok) {
      const { conversationId } = await res.json();
      router.push(`/chat/${conversationId}` as any);
    }
  }

  const activeFilterCount = Object.values(appliedFilters).filter(Boolean).length;

  return (
    <main className="relative mx-auto max-w-3xl px-4 py-8">
      <div className="bg-mesh" aria-hidden="true" />

      <motion.h1
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-2xl font-bold"
      >
        {t("title")}
      </motion.h1>
      <p className="mt-1 text-gray-600">{t("subtitle")}</p>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <div className="relative flex rounded-full bg-gray-100 p-1 text-sm font-medium">
          {(["matches", "all"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`relative z-10 rounded-full px-4 py-1.5 transition-colors ${
                mode === m ? "text-white" : "text-gray-600"
              }`}
            >
              {mode === m && (
                <motion.span
                  layoutId="matches-tab-pill"
                  className="absolute inset-0 -z-10 rounded-full bg-brand-600"
                  transition={{ type: "spring", stiffness: 400, damping: 32 }}
                />
              )}
              {m === "matches" ? t("tabMatches") : t("tabBrowseAll")}
            </button>
          ))}
        </div>

        <input
          value={country}
          onChange={(e) => setCountry(e.target.value)}
          placeholder={t("filterCountry")}
          className="rounded-full border border-gray-200 px-3.5 py-1.5 text-sm text-gray-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100"
        />
        <label className="flex items-center gap-2 text-sm text-gray-700">
          <input
            type="checkbox"
            checked={onlineOnly}
            onChange={(e) => setOnlineOnly(e.target.checked)}
          />
          {t("filterOnlineNow")}
        </label>

        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => setShowFilters((v) => !v)}
          className="ms-auto flex items-center gap-1.5 rounded-full border border-brand-200 bg-brand-50 px-4 py-1.5 text-sm font-medium text-brand-700"
        >
          🔎 {t("filtersButton")}
          {activeFilterCount > 0 && (
            <span className="rounded-full bg-brand-600 px-1.5 text-xs text-white">{activeFilterCount}</span>
          )}
          {!isPremium && <span className="text-xs">🔒</span>}
        </motion.button>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="card-shadow relative mt-3 rounded-2xl bg-white p-5">
              <h2 className="text-sm font-semibold text-gray-800">{t("filtersTitle")}</h2>

              <div
                className={`mt-3 grid grid-cols-1 gap-4 sm:grid-cols-3 ${
                  !isPremium ? "pointer-events-none opacity-40" : ""
                }`}
              >
                <div>
                  <label className="text-xs font-medium text-gray-600">{t("filterAgeRange")}</label>
                  <div className="mt-1 flex items-center gap-2">
                    <input
                      type="number"
                      min={16}
                      max={100}
                      value={minAge}
                      onChange={(e) => setMinAge(e.target.value)}
                      placeholder="18"
                      className="w-16 rounded-lg border border-gray-200 px-2 py-1.5 text-sm text-gray-900 outline-none focus:border-brand-500"
                    />
                    <span className="text-gray-400">–</span>
                    <input
                      type="number"
                      min={16}
                      max={100}
                      value={maxAge}
                      onChange={(e) => setMaxAge(e.target.value)}
                      placeholder="30"
                      className="w-16 rounded-lg border border-gray-200 px-2 py-1.5 text-sm text-gray-900 outline-none focus:border-brand-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-gray-600">{t("filterGender")}</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-gray-200 px-2 py-1.5 text-sm text-gray-900 outline-none focus:border-brand-500"
                  >
                    <option value="">{t("genderAny")}</option>
                    <option value="MALE">{t("genderMale")}</option>
                    <option value="FEMALE">{t("genderFemale")}</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-medium text-gray-600">{t("filterLanguage")}</label>
                  <select
                    value={languageCode}
                    onChange={(e) => setLanguageCode(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-gray-200 px-2 py-1.5 text-sm text-gray-900 outline-none focus:border-brand-500"
                  >
                    <option value="">{t("anyLanguage")}</option>
                    {languages.map((l) => (
                      <option key={l.code} value={l.code}>
                        {flagEmoji(l.code)} {l.nativeName}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {isPremium ? (
                <div className="mt-4 flex gap-2">
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={applyFilters}
                    className="rounded-full bg-brand-600 px-4 py-1.5 text-sm font-medium text-white"
                  >
                    {t("applyFilters")}
                  </motion.button>
                  <button
                    onClick={clearFilters}
                    className="rounded-full px-4 py-1.5 text-sm font-medium text-gray-500 hover:bg-gray-100"
                  >
                    {t("clearFilters")}
                  </button>
                </div>
              ) : (
                <div className="mt-4 flex flex-col items-center gap-2 rounded-xl bg-brand-50/80 p-4 text-center">
                  <p className="text-sm font-semibold text-gray-800">{t("filtersLockedTitle")}</p>
                  <p className="text-xs text-gray-600">{t("filtersLockedSubtitle")}</p>
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => router.push("/premium")}
                    className="mt-1 rounded-full bg-brand-600 px-4 py-1.5 text-sm font-medium text-white"
                  >
                    {t("upgradeButton")}
                  </motion.button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="h-32 animate-pulse rounded-2xl bg-gray-100" />
          ))}
        </div>
      ) : matches.length === 0 ? (
        <p className="mt-8 text-gray-500">{t("noResults")}</p>
      ) : (
        <ul className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <AnimatePresence initial={false}>
            {matches.map(({ user, matchScore }, i) => (
              <motion.li
                key={user.id}
                layout
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.35, delay: Math.min(i * 0.05, 0.3) }}
                whileHover={{ y: -3 }}
                className="card-shadow flex flex-col gap-2 rounded-2xl bg-white p-4 transition-shadow hover:card-shadow-lift"
              >
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 shrink-0 overflow-hidden rounded-full bg-gray-200">
                    {user.avatarUrl && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={user.avatarUrl}
                        alt={user.username}
                        className="h-full w-full object-cover"
                      />
                    )}
                  </div>
                  <div>
                    <p className="font-semibold">
                      {user.displayName || user.username}
                      {user.birthDate && (
                        <span className="ms-1.5 font-normal text-gray-500">
                          · {tProfile("yearsOld", { age: calculateAge(user.birthDate) })}
                        </span>
                      )}
                      {matchScore === 2 && (
                        <span className="ms-2 rounded-full bg-brand-100 px-2 py-0.5 text-xs text-brand-700">
                          ✓✓
                        </span>
                      )}
                    </p>
                    <p className="flex items-center gap-1 text-xs text-gray-500">
                      {user.country} {user.isOnline && "· ●"}
                    </p>
                  </div>
                </div>

                {user.languages.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {user.languages.map((l) => (
                      <span
                        key={l.languageCode + l.type}
                        className="flex items-center gap-1 rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-600"
                      >
                        <LanguageFlag code={l.languageCode} className="h-3 w-4 rounded-[1px]" />
                        {l.languageCode}
                      </span>
                    ))}
                  </div>
                )}

                {user.bio && <p className="line-clamp-2 text-sm text-gray-600">{user.bio}</p>}
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={() => sayHi(user.id)}
                  className="mt-1 self-start rounded-full bg-brand-600 px-4 py-1.5 text-sm font-medium text-white shadow-sm"
                >
                  {t("sendMessage")}
                </motion.button>
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>
      )}
    </main>
  );
}
